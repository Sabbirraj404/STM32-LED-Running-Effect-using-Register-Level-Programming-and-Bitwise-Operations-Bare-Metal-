#include <stdint.h>

void delay(void)
{
    for (volatile int i = 0; i < 500000; i++);
}

int main(void)
{
   volatile uint32_t *RCC_AHB1ENR = (uint32_t*)0x40023830;
   volatile uint32_t *GPIOA_MODER = (uint32_t*)0x40020000;
   volatile uint32_t *GPIOA_ODR   = (uint32_t*)0x40020014;


    *RCC_AHB1ENR |= (1 << 0);

    *GPIOA_MODER &= ~(0xFF << (5 *2));
    *GPIOA_MODER |= (0x55 << (5 *2));



    while(1){

    	*GPIOA_ODR =(1 << 5);
    	delay();

    	*GPIOA_ODR =(1 <<6 );
    	delay();

    	*GPIOA_ODR = (1 <<7 );
    	delay();

    	*GPIOA_ODR = (1 <<8);
    	delay();


    }
}
